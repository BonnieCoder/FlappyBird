using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance; 

    public Player birdBek;

    public static int finalScore;
    public Text scoreTxt;
    private int score = 0;

    private bool isGameOver = false;

    private void Awake(){
        if (instance == null){
            instance = this;
        } else if (instance != this){
            Destroy(gameObject);
        }
    }

    private void Update(){
        if (birdBek.isDead && !isGameOver){
            GameOver();
        }
    }

    public void IncreaseScore(){
        score++; 
        scoreTxt.text = score.ToString(); 
    }

    public void GameOver(){
        isGameOver = true;
        finalScore = score;
        SceneManager.LoadScene(2); 
    }
}