using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverSceneManager : MonoBehaviour
{
    public Text score;

    private void Start(){
        score.text = "Your score is " +  GameManager.finalScore.ToString();
    }

    public void RestartGame(){
        SceneManager.LoadScene(1);
    }
}
